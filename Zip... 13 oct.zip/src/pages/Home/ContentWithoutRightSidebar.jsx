// src/pages/HomePageContent.jsx
import React from 'react';
import WebStories from '../../components/MainArtical/WebStories'



const ContentWithoutRightSidebar = () => {
    return (
        <>
      
        <WebStories/>
        </>
    );
};
export default ContentWithoutRightSidebar;